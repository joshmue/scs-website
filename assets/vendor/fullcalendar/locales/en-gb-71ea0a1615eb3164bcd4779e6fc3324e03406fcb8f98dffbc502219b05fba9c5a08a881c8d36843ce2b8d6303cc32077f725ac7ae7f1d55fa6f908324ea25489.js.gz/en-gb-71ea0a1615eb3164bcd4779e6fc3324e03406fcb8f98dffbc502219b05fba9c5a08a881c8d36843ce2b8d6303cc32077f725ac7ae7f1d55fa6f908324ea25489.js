FullCalendar.globalLocales.push(function(){"use strict";var e;return{code:"en-gb",week:{dow:1,doy:4},buttonHints:{prev:"Previous $0",next:"Next $0",today:"This $0"},viewHint:"$0 view",navLinkHint:"Go to $0",moreLinkHint:e=>`Show ${e} more event${1===e?"":"s"}`}}());
//# sourceMappingURL=/assets/source-maps/vendor/fullcalendar/locales/en-gb.js.map
//# sourceURL=_assets/vendor/fullcalendar/locales/en-gb.js
